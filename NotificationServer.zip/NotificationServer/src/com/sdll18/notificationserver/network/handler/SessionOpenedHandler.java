package com.sdll18.notificationserver.network.handler;

import org.apache.mina.core.session.IoSession;

import com.sdll18.notificationserver.network.SessionManager;

public class SessionOpenedHandler {

	public static void handle(IoSession session) {
		SessionManager.getManager().addSession(session);
		// TODO
	}
}
