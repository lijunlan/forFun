package com.sdll18.Main;

public class MainFunction {

	public static void main(String[] args){
		
	}
}
