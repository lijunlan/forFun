package com.sdll18.main;

import com.sdll18.view.MyFrame;

public class MainFunction {

	public static void main(String[] args) {
		MyFrame frame = new MyFrame();
		frame.start();
	}

}
